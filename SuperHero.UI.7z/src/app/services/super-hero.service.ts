import { Injectable } from '@angular/core';
import { SuperHero } from '../models/super-hero';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment.development';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class SuperHeroService {
  
  private url = "SuperHero";
  constructor(private http: HttpClient) { }

  public getSuperHeroes() : Observable<SuperHero[]>{
    var ret = this.http.get<SuperHero[]>(`${environment.apiUrl}/${this.url}`);
    return ret;
  }

  public getSuperHero(id : number) : Observable<SuperHero>{
    var ret = this.http.get<SuperHero>(`${environment.apiUrl}/${this.url}/${id}`);
    return ret;
  }

  public updateSuperHero(hero : SuperHero) : Observable<SuperHero[]>{
    var ret = this.http.put<SuperHero[]>(`${environment.apiUrl}/${this.url}`,hero);
    return ret;
  }

  public createSuperHero(hero : SuperHero) : Observable<SuperHero[]>{
    var ret = this.http.post<SuperHero[]>(`${environment.apiUrl}/${this.url}`,hero);
    return ret;
  }

  public deleteSuperHero(hero : SuperHero) : Observable<SuperHero[]>{
    var ret = this.http.delete<SuperHero[]>(`${environment.apiUrl}/${this.url}/${hero.id}`);
    return ret;
  }
}
