import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SuperHero } from './models/super-hero';
import { SuperHeroService } from './services/super-hero.service';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { EditHeroComponent } from './components/edit-hero/edit-hero.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,CommonModule,HttpClientModule,EditHeroComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  heroToEdit: SuperHero|undefined;
  title = 'SuperHero.UI';
  heroes : SuperHero[] = [];

  constructor (private superHeroService: SuperHeroService){}

  ngOnInit(): void {
   this.superHeroService.getSuperHeroes().subscribe((result: SuperHero[]) => (this.heroes = result));
    //console.log(this.heroes);
  }

  updateHeroList(heroes: SuperHero[]){
    this.heroes = heroes;
  }
  editHero(hero: SuperHero) {
    this.heroToEdit = hero;
  }
  
  initNewHero() {
    this.heroToEdit = new SuperHero;
  }
  
}
