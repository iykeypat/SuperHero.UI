import { Component, EventEmitter, Input, OnInit, Output, output } from '@angular/core';
import { SuperHero } from '../../models/super-hero';
import { CommonModule } from '@angular/common';
import { SuperHeroService } from '../../services/super-hero.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-edit-hero',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './edit-hero.component.html',
  styleUrl: './edit-hero.component.css'
})
export class EditHeroComponent implements OnInit {

  @Input() hero?: SuperHero;
  @Output() updatedHeroes = new EventEmitter<SuperHero[]>;

  constructor(private superHeroService: SuperHeroService) { }

  ngOnInit(): void {
    //this.superHeroService.getSuperHero(1).subscribe((result: SuperHero) => (this.hero = result));
  }

  createHero(hero: SuperHero) {
    this.superHeroService.createSuperHero(hero).subscribe((result: SuperHero[]) => (this.updatedHeroes.emit(result)));
  }
    
  deleteHero(hero: SuperHero) {
    this.superHeroService.deleteSuperHero(hero).subscribe((result: SuperHero[]) => (this.updatedHeroes.emit(result)));
  }
  
  updateHero(hero: SuperHero) {
    this.superHeroService.updateSuperHero(hero).subscribe((result: SuperHero[]) => (this.updatedHeroes.emit(result)));
  }

}
