import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { environment } from './environments/environment.development';
import { CommonModule } from '@angular/common';

bootstrapApplication(AppComponent, {
  providers: [
    provideHttpClient(withFetch()),
    { provide: 'ENVIRONMENT', useValue: environment },
    { provide: 'appConfig', useValue: appConfig },
    { provide: 'CommonModule', useValue: CommonModule }
  ],
  
}).catch((err) => console.error(err));

// bootstrapApplication(AppComponent, appConfig)
//   .catch((err) => console.error(err));
