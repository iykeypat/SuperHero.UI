export const environment = {
    apiUrl : "https://localhost:7222/api",
};
